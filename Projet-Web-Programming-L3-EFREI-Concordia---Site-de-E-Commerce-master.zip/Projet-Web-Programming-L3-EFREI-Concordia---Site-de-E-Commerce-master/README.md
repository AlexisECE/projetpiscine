# Projet Web Programming L3 EFREI/Concordia - Site de E-Commerce

Projet Programmation Web (Web Programming) de L3 lors de mon séjour au Canada, à Montréal. Il s'agit d'un site de E-Commerce. Le contenu est en anglais. J'ai choisi comme thématique une boutique en ligne sur la vente de smartphones.
- Simulation de paiement par carte bancaire (vérification avec l'algorithme de Luhn)
- Panier client
- Compte client
- Interface d'administration (ajout, suppression, modification d'articles, réinitialisation de la base de données, inventaire)

Programmé en PHP (Version 7), MySQL (avec PhpMyAdmin), HTML5, CSS3 et une légère touche de Javascript.
Le contenu est en anglais.